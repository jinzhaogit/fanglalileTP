<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:76:"F:\PHP\WWW\WWW\jin_desgin\public/../application/admin\view\denglu\index.html";i:1495424175;}*/ ?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>房来乐，懂你想要的，，</title>
		<style>
			body{
				margin:0;
				color:#6a6f8c;
				background-image: url(INDEXIMG/bannerV2.jpg);
				font:600 16px/18px 'Open Sans',sans-serif;
			}
			*,:after,:before{box-sizing:border-box}
			.clearfix:after,.clearfix:before{content:'';display:table}
			.clearfix:after{clear:both;display:block}
			a{color:inherit;text-decoration:none;}
			input, button {
			  outline: none;
			  border: none;
			}
			.login-wrap{
				width:100%;
				margin:0 auto;
				max-width:525px;
				min-height:670px;
				position:relative;
				box-shadow:0 12px 15px 0 rgba(0,0,0,.24),0 17px 50px 0 rgba(0,0,0,.19);
			}
			.login-html{
				width:100%;
				height:100%;
				position:absolute;
				padding:0px 70px 5px 70px;
				background:rgba(40,57,101,.9);
			}
			.login-html p{
				color: #B452CD;
				font-size: 24px;text-align: center;
				margin-bottom: 50px;
			}
			.login-html .sign-in-htm,
			.login-html .sign-up-htm{
				top:0;
				left:0;
				right:0;
				bottom:0;
				position:absolute;
				-webkit-transform:rotateY(180deg);
				        transform:rotateY(180deg);
				-webkit-backface-visibility:hidden;
				        backface-visibility:hidden;
				-webkit-transition:all 1s linear;
				        transition:all 1s linear;
			}
			.login-html .sign-in,
			.login-html .sign-up,
			.login-form .group .check{
				display:none;
			}
			.login-html .tab,
			.login-form .group .label,
			.login-form .group .button{
				text-transform:uppercase;
			}
			.login-html .tab{
				font-size:22px;
				margin-right:15px;
				padding-bottom:5px;
				margin:0 15px 10px 0;
				display:inline-block;
				border-bottom:2px solid transparent;
			}
			.login-html .sign-in:checked + .tab,
			.login-html .sign-up:checked + .tab{
				color:#fff;
				border-color:#1161ee;
			}
			.login-form{
				min-height:345px;
				position:relative;
				-webkit-perspective:1000px;
				        perspective:1000px;
				-webkit-transform-style:preserve-3d;
				        transform-style:preserve-3d;
			}
			.login-form .group{
				margin-bottom:15px;
			}
			.login-form .group .label,
			.login-form .group .input,
			.login-form .group .button{
				width:100%;
				color:#fff;
				display:block;
			}
			.login-form .group .input,
			.login-form .group .button{
				border:none;
				padding:15px 20px;
				border-radius:25px;
				background:rgba(255,255,255,.1);
			}
			.login-form .group input[data-type="password"]{
				text-security:circle;
				-webkit-text-security:circle;
			}
			.login-form .group .label{
				color:#aaa;
				font-size:12px;
			}
			.login-form .group .button{
				background:#1161ee;
			}
			.login-form .group label .icon{
				width:15px;
				height:15px;
				border-radius:2px;
				position:relative;
				display:inline-block;
				background:rgba(255,255,255,.1);
			}
			.login-form .group label .icon:before,
			.login-form .group label .icon:after{
				content:'';
				width:10px;
				height:2px;
				background:#fff;
				position:absolute;
				-webkit-transition:all .2s ease-in-out 0s;
				        transition:all .2s ease-in-out 0s;
			}
			.login-form .group label .icon:before{
				left:3px;
				width:5px;
				bottom:6px;
				-webkit-transform:scale(0) rotate(0);
				    -ms-transform:scale(0) rotate(0);
				        transform:scale(0) rotate(0);
			}
			.login-form .group label .icon:after{
				top:6px;
				right:0;
				-webkit-transform:scale(0) rotate(0);
				    -ms-transform:scale(0) rotate(0);
				        transform:scale(0) rotate(0);
			}
			.login-form .group .check:checked + label{
				color:#fff;
			}
			.login-form .group .check:checked + label .icon{
				background:#1161ee;
			}
			.login-form .group .check:checked + label .icon:before{
				-webkit-transform:scale(1) rotate(45deg);
				    -ms-transform:scale(1) rotate(45deg);
				        transform:scale(1) rotate(45deg);
			}
			.login-form .group .check:checked + label .icon:after{
				-webkit-transform:scale(1) rotate(-45deg);
				    -ms-transform:scale(1) rotate(-45deg);
				        transform:scale(1) rotate(-45deg);
			}
			.login-html .sign-in:checked + .tab + .sign-up + .tab + .login-form .sign-in-htm{
				-webkit-transform:rotate(0);
				    -ms-transform:rotate(0);
				        transform:rotate(0);
			}
			.login-html .sign-up:checked + .tab + .login-form .sign-up-htm{
				-webkit-transform:rotate(0);
				    -ms-transform:rotate(0);
				        transform:rotate(0);
			}
			
			.hr{
				height:2px;
				margin:60px 0 50px 0;
				background:rgba(255,255,255,.2);
			}
			.foot-lnk{
				text-align:center;
			}
		</style>
	</head>
	<body>
		<div class="login-wrap">
		  <div class="login-html">
		  	<p>房来乐欢迎您</p>
		    <input id="tab-1" type="radio" name="tab" class="sign-in" checked><label for="tab-1" class="tab">登录</label>
		    <input id="tab-2" type="radio" name="tab" class="sign-up"><label for="tab-2" class="tab">注册</label>
		    <div class="login-form">
		      <form class="sign-in-htm" id="signfm">
		        <div class="group">
		          <label for="user" class="label">用户名</label>
		          <input id="user" name="name" type="text" class="input">
		        </div>
		        <div class="group">
		          <label for="pass" class="label">密码</label>
		          <input id="pass" name="pwd" type="password" class="input" data-type="password">
		        </div>
		        <div class="group">
		          <input id="check" type="checkbox" class="check" checked>
		          <label for="check"><span class="icon"></span> 记住我</label>
		        </div>
		        <div class="group">
		          <a class="button" id="btn" style="text-align: center;">登录</a>
		        </div>
		        <div class="hr"></div>
		        <div class="foot-lnk">
		          <a href="#forgot">忘记密码?</a>
		        </div>
		      </form>
		      <form class="sign-up-htm" id="signup">
		        <div class="group">
		          <label for="name" class="label">用户名</label>
		          <input id="user" name="name" type="text" class="input">
		        </div>
		        <div class="group">
		          <label for="sex" class="label">性别</label>
		          <input id="pass" name="sex" type="text" class="input">
		        </div>
		        <div class="group">
		          <label for="pwd" class="label">密码</label>
		          <input id="pass" name="pwd" type="password" class="input" data-type="password">
		        </div>
		        <div class="group">
		          <label for="rpwd" class="label">确认密码</label>
		          <input id="pass" name="rpwd" type="password" class="input" data-type="password">
		        </div>
		        <div class="group">
		          <label for="address" class="label">所在地</label>
		          <input id="pass" name="address" type="text" class="input">
		        </div>
		        <div class="group">
		          <a class="button" id="btnup" style="text-align: center;">注册</a>
		        </div>
		        <div class="hr"></div>
		      </form>
		    </div>
		  </div>
		</div>
	</body>
	<script type="text/javascript" src="ADMINJS/jquery.js" ></script>
	<script type="text/javascript" src="ADMINJS/sign.js"></script>
	<script type="text/javascript" src="ADMINJS/common.js" ></script>
</html>

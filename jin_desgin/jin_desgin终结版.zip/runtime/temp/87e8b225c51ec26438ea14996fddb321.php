<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:74:"F:\PHP\WWW\WWW\jin_desgin\public/../application/main\view\lease\index.html";i:1494657071;}*/ ?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8" />
		<title>房来乐,懂你想要的，，</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no" />
		<link rel="shortcut icon" href="MAINIMG/logo.jpg" type="image/x-icon" />
		<link rel="stylesheet" href="MAINCSS/index.css" />
		<script type="text/javascript" src="MAINJS/jquery1.42.min.js" ></script>
		<script type="text/javascript" src="MAINJS/index.js" ></script>
		<script type="text/javascript" src="MAINJS/jquery.SuperSlide.2.1.1.js" ></script>
		<script type="text/javascript" src="MAINJS/page.js" ></script>
	</head>
	<body>
		<!--导航栏-->
		<section class="nav">		
			<ul>
				<li><img src="MAINIMG/logo.jpg" /></li>
				<a href="/main/Index/index"><li>首页</li></a>
				<a href="/main/Business/index"><li>买卖</li></a>
				<a href="/main/Lease/index"><li>租赁</li></a>
				<a href="/main/Inn/index"><li>客栈</li></a>
				<a href="/main/Life/index"><li>生活帮</li></a>
			</ul>
			<div class="nav-right">
				<a class="nav-right-a" href="/admin/denglu/index">注册 | 登录</a>
				<a href="/admin/denglu/index">退出</a>
			</div>	
		</section>
		<!--轮播图-->
		<section class="body">
		<div id="slideBox" class="slideBox">
			<div class="hd">
				<ul><li></li><li></li><li></li></ul>
			</div>
			<div class="bd">
				<ul>
					<li><a href="http://www.SuperSlide2.com" target="_blank"><img src="MAINIMG/lunbotu/webwxgetmsgimg (10).jpg" /></a></li>
					<li><a href="http://www.SuperSlide2.com" target="_blank"><img src="MAINIMG/lunbotu/webwxgetmsgimg (7).jpg" /></a></li>
					<li><a href="http://www.SuperSlide2.com" target="_blank"><img src="MAINIMG/lunbotu/webwxgetmsgimg (9).jpg " /></a></li>
				</ul>
			</div>
		</div>
		<!--热售房源-->
		<section class="hot">
			<div style="height: 100%;width: 90%;margin: auto; background-color: #fff;">
			<div class="header"><h2>热门推荐>></h2></div>
			<div class="center">
				<img src="MAINIMG/fang/timg (1).jpg" />
				<div class="cen-right">
					<h3>滨江大盘升级回归 外滩新城二期住宅面世</h3>
					<h4>户型151-188平米</h4>
					<p>世茂外滩新城位于鼓楼滨江，是区域版块内建设较早的一个项目，项目集住宅、商业、写字楼、酒店于一体，一期住宅已交付入住。项目预计12月加推二期住宅的10号楼，此次加推的房源相对于前期品质有所提升。世茂外滩新城位于鼓楼滨江，是区域版块内建设较早的一个项目，项目集住宅、商业、写字楼、酒店于一体，一期住宅已交付入住。项目预计12月加推二期住宅的10号楼，此次加推的房源相对于前期品质有所提升。世茂外滩新城位于鼓楼滨江，是区域版块内建设较早的一个项目，项目集住宅、商业、写字楼、酒店于一体，一期住宅已交付入住。项目预计12月加推二期住宅的10号楼，此次加推的房源相对于前期品质有所提升。</p>
					<span>2017-07-11 &nbsp;11:30:57<i>98</i></span>
				</div>
			</div>
			<div class="center">
				<img src="MAINIMG/fang/timg (9).jpg" />
				<div class="cen-right">
					<h3>[雨花台 城南] 恒大华府</h3>
					<h4>户型51-88平米</h4>
					<p>建筑面积约200平米，五房两厅两卫格局。采用明厅、明厨、明厕、明走道、明卧室的全五明设计,采光、通风效果绝佳。一期住宅已交付入住。项目预计12月加推二期住宅的10号楼，此次加推的房源相对于前期品质有所提升。世茂外滩新城位于鼓楼滨江，是区域版块内建设较早的一个项目，项目集住宅、商业、写字楼、酒店于一体，一期住宅已交付入住。项目预计12月加推二期住宅的10号楼，此次加推的房源相对于前期品质有所提升。世茂外滩新城位于鼓楼滨江，是区域版块内建设较早的一个项目，项目集住宅、商业、写字楼、酒店于一体，一期住宅已交付入住。项目预计12月加推二期住宅的10号楼，此次加推的房源相对于前期品质有所提升。</p>
					<span>2017-06-21 &nbsp;11:30:57<i>75</i></span>
				</div>
			</div>
			<div class="center">
				<img src="MAINIMG/fang/timg (3).jpg" />
				<div class="cen-right">
					<h3>高新四季花城黄金 2室2厅 85平米 精装修 年付</h3>
					<h4>户型55-68平米</h4>
					<p>世茂外滩新城位于鼓楼滨江，是区域版块内建设较早的一个项目，项目集住宅、商业、写字楼、酒店于一体，一期住宅已交付入住。项目预计12月加推二期住宅的10号楼，此次加推的房源相对于前期品质有所提升。世茂外滩新城位于鼓楼滨江，是区域版块内建设较早的一个项目，项目集住宅、商业、写字楼、酒店于一体，一期住宅已交付入住。项目预计12月加推二期住宅的10号楼，此次加推的房源相对于前期品质有所提升。世茂外滩新城位于鼓楼滨江，是区域版块内建设较早的一个项目，项目集住宅、商业、写字楼、酒店于一体，一期住宅已交付入住。项目预计12月加推二期住宅的10号楼，此次加推的房源相对于前期品质有所提升。</p>
					<span>2017-07-21 &nbsp;11:30:57<i>77</i></span>
				</div>
			</div>
			<div class="center">
				<img src="MAINIMG/fang/timg (4).jpg" />
				<div class="cen-right">
					<h3>[浦口 江北] 苏宁北外滩水城</h3>
					<h4>户型151-188平米</h4>
					<p>世茂外滩新城位于鼓楼滨江，是区域版块内建设较早的一个项目，项目集住宅、商业、写字楼、酒店于一体，一期住宅已交付入住。项目预计12月加推二期住宅的10号楼，此次加推的房源相对于前期品质有所提升。世茂外滩新城位于鼓楼滨江，是区域版块内建设较早的一个项目，项目集住宅、商业、写字楼、酒店于一体，一期住宅已交付入住。项目预计12月加推二期住宅的10号楼，此次加推的房源相对于前期品质有所提升。世茂外滩新城位于鼓楼滨江，是区域版块内建设较早的一个项目，项目集住宅、商业、写字楼、酒店于一体，一期住宅已交付入住。项目预计12月加推二期住宅的10号楼，此次加推的房源相对于前期品质有所提升。</p>
					<span>2017-06-16 &nbsp;11:30:57<i>68</i></span>
				</div>
			</div>
			<div class="center">
				<img src="MAINIMG/fang/timg (5).jpg" />
				<div class="cen-right">
					<h3>山阳 焦东北路一号 2室 1厅 50平米</h3>
					<h4>户型151-188平米</h4>
					<p>世茂外滩新城位于鼓楼滨江，是区域版块内建设较早的一个项目，项目集住宅、商业、写字楼、酒店于一体，一期住宅已交付入住。项目预计12月加推二期住宅的10号楼，此次加推的房源相对于前期品质有所提升。世茂外滩新城位于鼓楼滨江，是区域版块内建设较早的一个项目，项目集住宅、商业、写字楼、酒店于一体，一期住宅已交付入住。项目预计12月加推二期住宅的10号楼，此次加推的房源相对于前期品质有所提升。世茂外滩新城位于鼓楼滨江，是区域版块内建设较早的一个项目，项目集住宅、商业、写字楼、酒店于一体，一期住宅已交付入住。项目预计12月加推二期住宅的10号楼，此次加推的房源相对于前期品质有所提升。</p>
					<span>2017-07-18 &nbsp;11:30:57<i>40</i></span>
				</div>
			</div>
			<div class="center">
				<img src="MAINIMG/fang/timg.jpg" />
				<div class="cen-right">
					<h3>一月600到1000元 压一付三 价格面议</h3>
					<h4>户型151-188平米</h4>
					<p>世茂外滩新城位于鼓楼滨江，是区域版块内建设较早的一个项目，项目集住宅、商业、写字楼、酒店于一体，一期住宅已交付入住。项目预计12月加推二期住宅的10号楼，此次加推的房源相对于前期品质有所提升。世茂外滩新城位于鼓楼滨江，是区域版块内建设较早的一个项目，项目集住宅、商业、写字楼、酒店于一体，一期住宅已交付入住。项目预计12月加推二期住宅的10号楼，此次加推的房源相对于前期品质有所提升。世茂外滩新城位于鼓楼滨江，是区域版块内建设较早的一个项目，项目集住宅、商业、写字楼、酒店于一体，一期住宅已交付入住。项目预计12月加推二期住宅的10号楼，此次加推的房源相对于前期品质有所提升。</p>
					<span>2017-07-09 &nbsp;11:30:57<i>55</i></span>
				</div>
			</div>
			<!--分页-->
			<div class="pageTest"></div>
			<!--结尾版权-->
			<section class="footer">
				<p>首页 || 买卖 || 租赁 || 客栈 || 生活帮 || 关于我们</p>
				<p>Copyright©1999-2017, ctrip.com. All rights reserved. | ICP证：沪B2-20050130
				<p 豫公网备31010502000018号</p>
				<p>房产违法行为举报电话110 丨服务质量投诉电话 110丨河南省房产网站落实诚信建设主体责任承诺书</p>
			</section>
			</div>
		</section>
	</body>
</html>

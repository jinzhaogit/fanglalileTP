<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:74:"F:\PHP\WWW\WWW\jin_desgin\public/../application/main\view\index\index.html";i:1494657059;}*/ ?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8" />
		<title>房来乐,懂你想要的，，</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no" />
		<link rel="shortcut icon" href="MAINIMG/logo.jpg" type="image/x-icon" />
		<link rel="stylesheet" href="MAINCSS/index.css" />
		<script type="text/javascript" src="MAINJS/jquery.js" ></script>
		<script type="text/javascript" src="MAINJS/index.js" ></script>
	</head>
	<body>
		<!--导航栏-->
		<section class="nav">		
			<ul>
				<li><img src="MAINIMG/logo.jpg" /></li>
				<a href="/main/Index/index"><li>首页</li></a>
				<a href="/main/Business/index"><li>买卖</li></a>
				<a href="/main/Lease/index"><li>租赁</li></a>
				<a href="/main/Inn/index"><li>客栈</li></a>
				<a href="/main/Life/index"><li>生活帮</li></a>
			</ul>
			<div class="nav-right">
				<a class="nav-right-a" href="/admin/denglu/index">注册 | 登录</a>
				<a href="/admin/denglu/index">退出</a>
			</div>	
		</section>
		<!--背景图-->
		<div class="img">
			<img src="MAINIMG/bannerV2.jpg" />
		</div>
		<!--炫酷粒子-->
		<section class="lizi">
			<img src="MAINIMG/bannerV2.jpg"/>
			<h2>房 来 乐</h2>
			<h1>FangLaiLe give you the life you want</h1>
			<p>有房，有你，有乐，有生活</p>
			<!--搜索-->
			<section class="refresh">
				<p>我要买新房，租住所，找客栈，会生活...</p>
				<div class="refresh-right">点我搜索</div>
			</section>
		</section>
		<div class="html" style="background: #fff;">
		<!--简要介绍-->
		<section class="fun">
			<div class="fun-item">
				<h2>&nbsp;&nbsp; &nbsp;房来乐，会生活，给你想要的生活</h3>
				<h3>&nbsp; &nbsp; &nbsp;room to music,will live</h4>
				<p>&nbsp; &nbsp; &nbsp;房来乐，网络租房，房东直租，无任何中介费赚差价，诞生于2017年6月份，跟随着大学生毕业一起走向社会，服务社会，报答社会，房来乐以诚实守信，认真负责，尽我所能，用心服务的口号在社会各个角落漫步，随时恭候有需要的人们，主要经营一手买卖，房屋租赁，优惠宾馆的推送，为你找到一个落脚点，一个舒服的家，一个愉快的生活.</p>
			</div>
			<div class="fun-item2">
				<ul>
					<li><img src="MAINIMG/001.jpg" /> </li>
					<li><img src="MAINIMG/002.jpg" /> </li>
					<li><img src="MAINIMG/003.jpg" /> </li>
					<li><img src="MAINIMG/004.jpg" /> </li>
				</ul>
			</div>
		</section>
		<!--主要业务-->
		<section class="business">
			<h2>主要业务</h2>
			<p>房来乐主要为了成为二手市场领导者，对二手物品进行全方位交易，给二手物品一个品质平台</p>
			<p>二手、新房、租房，随时随地任性找房,在线咨询让您放心，消息动态推送让您省心，服务承诺让您安心，数据百科锦囊让您感受贴心漫漫找房路</p>
			<ul>
				<li><img src="MAINIMG/php6ifmLs.png"/><h2>一手买卖</h2></li>
				<li><img src="MAINIMG/phpe022WE.png"/><h2>二手租赁</h2></li>
				<li><img src="MAINIMG/php4TtmtO.png"/><h2>身边客栈</h2></li>
				<li><img src="MAINIMG/phpDVtHdC1456382078.png"/><h2>生活帮助</h2></li>
			</ul>
		</section>
		<section class="resources">
			<div class="photo">
			<h2>我们的资源</h2>
			<p>房来乐未来打造海量真实房源，500强企业合作伙伴，拥有全球忠实粉丝</p>
			<ul>
				<li><img src="MAINIMG/fang/timg (1).jpg"/></li>
				<li><img src="MAINIMG/fang/timg (2).jpg"/></li>
				<li><img src="MAINIMG/fang/timg (3).jpg"/></li>
				<li><img src="MAINIMG/fang/timg (4).jpg"/></li>
				<li><img src="MAINIMG/fang/timg (5).jpg"/></li>
				<li><img src="MAINIMG/fang/timg (6).jpg"/></li>
				<li><img src="MAINIMG/fang/timg (7).jpg"/></li>
				<li><img src="MAINIMG/fang/timg (8).jpg"/></li>
				<li><img src="MAINIMG/fang/timg (9).jpg"/></li>
				<li><img src="MAINIMG/fang/timg.jpg"/></li>
			</ul>
			</div>
		</section>
		<!--我们的团队-->
		<section class="team">
			<h2>我们的领导</h2>
			<p>强大的房来乐需要强大的大佬们，他们是精英，更是骄傲</p>
			<p>Powerful room to music needs strong bigwigs who are elite, but also proud</p>
			<ul>
				<li><img src="MAINIMG/mayun.jpg"/><h2>马云</h2><h3>职务：副总裁</h3><p>男，1964年9月10日生于浙江省杭州市， 房来乐集团主要创始人，现担任房来乐集团董事局副主席、华谊兄弟董事.</p> </li>
				<li><img src="MAINIMG/jinzhao.jpg"/><h2>金昭</h2><h3>职务：巡逻队长</h3><p>男，1995年12月24日生于河南省栓光山县， 房来乐集团主要创始人，毕业于焦作大学，现担任房来乐集团董事局主席</p> </li>
				<li><img src="MAINIMG/xijingp.jpg"/><h2>习近平</h2><h3>职务：财务部长</h3><p>男，1953年6月生于陕西富平人，清华大学人文社会学院马克思主义理论与思想政治教育专业毕业</p> </li>
			</ul>
		</section>
		<!--我们的合作伙伴-->
		<section class="friends">
			<h2>合作伙伴</h2>
			<p>房来乐贯穿全球，拥有多个知名企业合作记录，给多个企业创下汗马功劳</p>
			<ul>
				<li><img src="MAINIMG/logo/jindong.jpg" /></li>
				<li><img src="MAINIMG/logo/9109777_103701339000_2.jpg" /></li>
				<li><img src="MAINIMG/logo/aliyun.png" /></li>
				<li><img src="MAINIMG/logo/guge.jpg" /></li>
				<li><img src="MAINIMG/logo/huawei.jpg" /></li>
				<li><img src="MAINIMG/logo/012logo-guojiqiye (134).jpg" /></li>
				<li><img src="MAINIMG/logo/taobao.jpg" /></li>
				<li><img src="MAINIMG/logo/tianmao.jpg" /></li>
			</ul>
		</section>
		<!--结尾版权-->
		<section class="footer">
			<p>首页 || 买卖 || 租赁 || 客栈 || 生活帮 || 关于我们</p>
			<p>Copyright©1999-2017, ctrip.com. All rights reserved. | ICP证：沪B2-20050130
			<p 豫公网备31010502000018号</p>
			<p>房产违法行为举报电话110 丨服务质量投诉电话 110丨河南省房产网站落实诚信建设主体责任承诺书</p>
		</section>
		</div>
	</body>
</html>

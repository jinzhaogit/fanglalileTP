<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:75:"F:\PHP\WWW\WWW\jin_desgin\public/../application/admin\view\admin\index.html";i:1494634769;}*/ ?>
<table id="datagrid"></table> 
<div id="tb">
	<a href="#" class="easyui-linkbutton" data-options="iconCls:'icon-add',plain:true" onclick="dept.add();" />增加</a>
	<a href="#" class="easyui-linkbutton" data-options="iconCls:'icon-remove',plain:true" onclick="dept.del();"/>删除</a>
	<a href="#" class="easyui-linkbutton" data-options="iconCls:'icon-edit',plain:true" onclick="dept.edit();"/>修改</a>
</div>
<div id="win">
	<form id="fmdept" method="post">     
        <p><label for="name">姓名:</label> 
        </p> <input class="easyui-validatebox" type="text" name="name" data-options="required:true" />   
        <p><label for="pwd">密码:</label>
        </p><input class="easyui-validatebox" type="password" name="pwd" data-options="required:true" />    
        <p><label for="sex">性别:</label>   
        </p><input class="easyui-validatebox" type="text" name="sex"/>     
        <p><label for="address">地址:</label>   
        </p><input class="easyui-validatebox" type="text" name="address" />   
	</form>  
</div> 
<script type="text/javascript" src="ADMINJS/index.js" ></script>

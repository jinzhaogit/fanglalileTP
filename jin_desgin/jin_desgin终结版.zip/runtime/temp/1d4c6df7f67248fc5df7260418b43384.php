<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:73:"F:\PHP\WWW\WWW\jin_desgin\public/../application/main\view\life\index.html";i:1495076484;}*/ ?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8" />
		<title>房来乐,懂你想要的，，</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no" />
		<link rel="shortcut icon" href="MAINIMG/logo.jpg" type="image/x-icon" />
		<link rel="stylesheet" href="MAINCSS/index.css" />
		<script type="text/javascript" src="MAINJS/jquery.js" ></script>
		<script type="text/javascript" src="MAINJS/index.js" ></script>
	</head>
	<body>
		<!--导航栏-->
		<section class="nav">		
			<ul>
				<li><img src="MAINIMG/logo.jpg" /></li>
				<a href="/main/Index/index"><li>首页</li></a>
				<a href="/main/Business/index"><li>买卖</li></a>
				<a href="/main/Lease/index"><li>租赁</li></a>
				<a href="/main/Inn/index"><li>客栈</li></a>
				<a href="/main/Life/index"><li>生活帮</li></a>
			</ul>
			<div class="nav-right">
				<a class="nav-right-a" href="/admin/denglu/index">注册 | 登录</a>
				<a href="/admin/denglu/index">退出</a>
			</div>	
		</section>
		<!--生活帮-->
		<!--马蜂窝-->
		<div style="height: 60px;background: #fff;"></div>
		 <section class="triangle">
		 	<ul>
		 		<li><img src="MAINIMG/life/zixingche.jpg" /> </li>
		 		<li><img src="MAINIMG/life/tiyuqicai.jpg" /> </li>
		 		<li><img src="MAINIMG/life/dache.jpg" /></li>
		 		<li><a href="http://127.0.0.1/jinzhao/index.html"><img src="MAINIMG/life/wangye.jpg" /></a> </li>
		 		<li><img src="MAINIMG/life/weixiu.jpg" /></li>
		 		<li><img src="MAINIMG/life/gou.jpg" /> </li>
		 		<li><img src="MAINIMG/life/jianzhi.jpg" /> </li>
		 		<li><img src="MAINIMG/life/ktv.jpg" /> </li>
		 		<li><img src="MAINIMG/life/lvyou.jpg" /> </li>
		 		<li><img src="MAINIMG/life/paobu.jpg" /> </li>
		 		<li><img src="MAINIMG/life/qiu.jpg" /> </li>
		 		<li><img src="MAINIMG/life/yuehui.jpg" /> </li>
		 	</ul>
		 	<ul>
		 		<li><img src="MAINIMG/life/fabu.jpg"/></li>
		 		<li><img src="MAINIMG/life/yuema.jpg"/></li>
		 		<li><img src="MAINIMG/life/qiuzhu.jpg"/></li>
		 		<li><a href="tencent://message/?uin=2214651145&Site=http://vps.shuidazhe.com&Menu=yes"><img src="MAINIMG/life/lainxiwo.jpg"/></a> </li>
		 	</ul>
		 </section>
	</body>
</html>

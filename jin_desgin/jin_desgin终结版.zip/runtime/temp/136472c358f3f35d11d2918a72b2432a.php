<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:75:"F:\PHP\WWW\WWW\jin_desgin\public/../application/index\view\index\index.html";i:1494649888;s:77:"F:\PHP\WWW\WWW\jin_desgin\public/../application/index\view\public\layout.html";i:1494634750;}*/ ?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>房来乐，懂你想要的，，</title>
		<link rel="stylesheet" href="EASYUI/easyui.css" />
		<link rel="stylesheet" href="EASYUI/icon.css" />
		<script type="text/javascript" src="EASYUI/jquery.min.js" ></script>
		<script type="text/javascript" src="EASYUI/jquery.easyui.min.js" ></script>
		<script type="text/javascript" src="EASYUI/easyui-lang-zh_CN.js" ></script>
		<script type="text/javascript" src="ADMINJS/common.js" ></script>
	</head>
	
<body class="easyui-layout">   
    <div data-options="region:'north'," style="height:30px;line-height: 30px; text-align: center;font-size: 24px;overflow: hidden;">房来乐管理系统</div>   
    <div data-options="region:'south'," style="height:26px;text-align: center;line-height: 26px;font-size: 14px;">@copy版权：房来乐</div>   
    <div data-options="region:'east',iconCls:'icon-reload',title:'小助手',split:true" style="width:100px;"></div>   
    <div data-options="region:'west',title:'导航栏',split:true" style="width:150px;">
    	<ul id="tree"></ul> 
    </div>   
    <div data-options="region:'center',title:'主要内容'" style="padding:5px;background:#eee;">
    	<div id="tabs" class="easyui-tabs" style="width:100%;height:100%;">   
		    <div title="主页" data-options="closable:false" style="padding:20px;display:none;">   
		      	<img src="INDEXIMG/fangg.jpg" style="text-align: center;margin-left: 32%; "  />
		      	<img src="INDEXIMG/lail.jpg" style="text-align: center;margin-left: 26%;height: 135px; " />
		      	<p style="text-align: center;font-size: 30px;color: darkmagenta;"> 房来乐，有房，有你，有乐，有生活 </p>
		    </div> 
		</div>  
    </div>   
</body>
<div id="menu" class="easyui-menu" style="width:80px;">    
    <div>刷新</div>   
    <div>关闭</div>   
    <div>关闭其他</div>   
    <div>全部关闭</div>   
</div>  
<script type="text/javascript">
	var treeUrl="<?php echo URL('tree'); ?>";
</script>
<script type="text/javascript" src="INDEXJS/index.js" ></script>


</html>

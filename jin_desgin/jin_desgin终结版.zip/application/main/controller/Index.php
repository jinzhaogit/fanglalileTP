<?php
namespace app\main\controller;
use think\Controller;
class Index extends Controller{
	public function index(){
		return view();
	}
}
?>
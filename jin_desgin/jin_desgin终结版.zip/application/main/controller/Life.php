<?php
namespace app\main\controller;
use think\Controller;
class Life extends Controller{
	public function index(){
		return view();
	}
}

?>
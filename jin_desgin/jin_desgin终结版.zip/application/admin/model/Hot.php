<?php
namespace app\admin\model;
use think\Model;
class Hot extends Model{
	
}

?>
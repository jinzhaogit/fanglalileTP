<?php
namespace app\admin\model;
use think\Model;
class Article extends Model{
	
}

?>
<?php
namespace app\admin\model;
use think\Model;
class Column extends Model{
	
}

?>
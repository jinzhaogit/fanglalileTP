$(function(){
	var $tree,$tabs,$menu;
	$tree=$('#tree');$tabs=$('#tabs');$menu=$('#menu');
	$tree.tree({    
    	url:treeUrl,
    	animate:true,
    	lines:true,
    	onClick: function(node){
    		if($tree.tree('isLeaf',node.target)){
    			if($tabs.tabs('exists',node.text)){
    				$tabs.tabs('select',node.text);
    			}else{
    				$tabs.tabs('add',{    
					    title:node.text,    
					    href:node.url,    
					    closable:true,    
					    tools:[{    
					        iconCls:'icon-mini-refresh',    
					        handler:function(){    
					            refreshfun();  
					        }    
					    }]    
					}); 
    			}
    		}	 
		}
	});  
	$tabs.tabs({
		fit:true,
		onContextMenu:function(e, title,index){
			e.preventDefault();
			$menu.menu('show', {    
			  left: e.pageX,    
			  top: e.pageY, 
			  onClick:function(item){
			  	if(item.text=='刷新'){
			  		refreshfun(title);
			  	}
			  	if(item.text=='关闭'){
			  		closefun(title);
			  	}
			  	var tabsArry=[];
			  	var data=$tabs.tabs('tabs');
			  	$.each(data, function() {
			  		var p=$(this).panel('options');
			  		if((item.text=='关闭其他')&&(p.title!=title)&&(p.closable)){
			  			tabsArry.push(p.title);
			  		}
			  		if((item.text=='全部关闭')&&(p.closable)){
			  			tabsArry.push(p.title);
			  		}
			  	});
			  	for(var i=0;i<tabsArry.length;i++){
			  		closefun(tabsArry[i]);
			  	}
			  }
			});
		},
	});
	function refreshfun(title){
		var tab=$tabs.tabs('getTab',title);
		var opts=tab.panel('options');
		$tabs.tabs('update', {
			tab: tab,
			options: opts,
		});
		alert('刷新成功~');
	}
	function closefun(title){
		$tabs.tabs('close',title);
	}
})

$(function(){
	$('#btn').click(function(){
		var signFm=serializeObject($('#signfm'));
		$.post('/admin/Denglu/sign',{ostr:JSON.stringify(signFm)},function(data){
			if(data>0){
				window.location.href='/main/index/index';
			}else{
				alert('呜呜~登陆失败，请重试~');
			}
		});
	});
//	注册
	$('#btnup').click(function(){
		var signupFm=serializeObject($('#signup'));
		var upPwd=signupFm['pwd'];
		var upRpwd=signupFm['rpwd'];
		if(upPwd==upRpwd){
			$.post('/admin/Denglu/signup',{ostr:JSON.stringify(signupFm)},function(data){
			if(data==1){
				alert('亲爱的，注册成功，赶快抓紧登录吧~');
				window.location.href='/admin/denglu/index';
			}else{
				alert('呜呜~注册失败，请重试~');
			}
			});
		}else{
			alert('密码不一致');
		}
		
	});
	
})

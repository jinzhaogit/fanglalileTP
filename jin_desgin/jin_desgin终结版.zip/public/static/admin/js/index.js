$(function(){
	var $datagrid,$win,$fmdept;
	$datagrid=$('#datagrid');$win=$('#win');$fmdept=$('#fmdept');
	$datagrid.datagrid({    
	    url:'/admin/Index/getTabs',  
	    fitColumns:true,
	    striped:true,
	    fit:true,
	    pagination:true,
	    rownumbers:true,
	    singleSelect:true, 
	    pageSize:5,
		pageList:[5,10,15,20,25],	    
	    toolbar: '#tb',
	    columns:[[    
	        {field:'id',title:'ID',width:100},    
	        {field:'name',title:'姓名',width:200}, 
	        {field:'sex',title:'性别',width:200},    
	        {field:'address',title:'所在地',width:200},  
	        {field:'pwd',title:'密码',width:200,lign:'right'}    
	    ]],   
	}); 
	dept={
		url:'',
		add:function(){
			this.url='/admin/Index/deptAdd';
			dept.aid();
		},
		del:function(){
			this.url='/admin/Index/deptDel';
			var rows=$datagrid.datagrid('getSelected');
			if(rows){
				$.post(this.url,{id:rows.id},function(data, textStatus, xhr){
					if(data>0){
						$.messager.show({
							title:'我的消息',
							msg:'删除成功~',
							timeout:2000,
							showType:'slide'
							});
						}else{
							alert('呜呜~抱歉,操作失败,请重试~');
						}
					$datagrid.datagrid('reload');
				});
			}else{
				alert('亲，请先选中一行哦~');
			}
		},
		edit:function(){
			this.url='/admin/Index/deptEdit';
			var rows=$datagrid.datagrid('getSelected');
			if(rows){
				$fmdept.form('load',rows);
				dept.aid();	
			}else{
				alert('温馨提醒:亲,请先选中一行数据哦~谢谢');
			}
			
		},
		query:function(){
			this.url='/admin/Index/deptQuery';
			var name=$('#qname').val();
			var sex=$('#qsex').val();
			$datagrid.datagrid('load', {    
			    name: name,    
			    sex: sex,   
			}); 
		},
		save:function(){
			var deptFm=serializeObject($fmdept);
			$.post(this.url,{ostr:JSON.stringify(deptFm)},function(data, textStatus, xhr){
				if(data>0){
					$.messager.show({
						title:'我的消息',
						msg:'保存成功~',
						timeout:2000,
						showType:'slide'
					});
				}else{
					alert('呜呜~抱歉,操作失败,请重试~');
				}
				$win.window('close');
				$datagrid.datagrid('reload');
			});
		},
		aid:function(){
			$win.dialog({    
			    title: '我的管理',    
			    width: 250,    
			    height: 350,    
			    closed: false,    
			    cache: false,       
			    modal: true,
			    buttons:[{
					text:'保存',
					iconCls:'icon-save',
					handler:function(){
						dept.save();
					}
				},{
					text:'取消',
					iconCls:'icon-no',
					handler:function(){
						$win.window('close');
					}
				}],
			}); 
		},
	};
}) 
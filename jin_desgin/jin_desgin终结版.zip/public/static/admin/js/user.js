$(function(){
	var $datagridUser,$winUser,$fmdeptUser;
	$datagridUser=$('#datagridUser');$winUser=$('#winUser');$fmdeptUser=$('#fmdeptUser');
	$datagridUser.datagrid({    
	    url:'/admin/User/getTabsUser',  
	    fitColumns:true,
	    striped:true,
	    fit:true,
	    pagination:true,
	    rownumbers:true,
	    singleSelect:true, 
	    pageSize:5,
		pageList:[5,10,15,20,25],	    
	    toolbar: '#tbUser',
	    columns:[[    
	        {field:'id',title:'ID',width:100},    
	        {field:'name',title:'姓名',width:200}, 
	        {field:'sex',title:'性别',width:200},    
	        {field:'address',title:'所在地',width:200},  
	        {field:'pwd',title:'密码',width:200,lign:'right'}    
	    ]],   
	}); 
	User={
		url:'',
		add:function(){
			this.url='/admin/User/deptAddUser';
			$fmdeptUser.form('clear');
			User.aid();
		},
		del:function(){
			this.url='/admin/User/deptDelUser';
			var rows=$datagridUser.datagrid('getSelected');
			if(rows){
				$.post(this.url,{id:rows.id},function(data, textStatus, xhr){
					if(data>0){
						$.messager.show({
							title:'我的消息',
							msg:'删除成功~',
							timeout:2000,
							showType:'slide'
							});
						}else{
							alert('呜呜~抱歉,操作失败,请重试~');
						}
					$datagridUser.datagrid('reload');
				});
			}else{
				alert('亲，请先选中一行哦~');
			}
		},
		edit:function(){
			this.url='/admin/User/deptEditUser';
			var rows=$datagridUser.datagrid('getSelected');
			if(rows){
				$fmdeptUser.form('load',rows);
				User.aid();	
			}else{
				alert('温馨提醒:亲,请先选中一行数据哦~谢谢');
			}
			
		},
		query:function(){
			this.url='/admin/User/deptQueryUser';
			var name=$('#qnameUser').val();
			var sex=$('#qsexUser').val();
			$datagridUser.datagrid('load', {    
			    name: name,    
			    sex: sex,   
			}); 
		},
		save:function(){
			var deptFm=serializeObject($fmdeptUser);
			$.post(this.url,{ostr:JSON.stringify(deptFm)},function(data, textStatus, xhr){
				if(data>0){
					$.messager.show({
						title:'我的消息',
						msg:'保存成功~',
						timeout:2000,
						showType:'slide'
					});
				}else{
					alert('呜呜~抱歉,操作失败,请重试~');
				}
				$winUser.window('close');
				$datagridUser.datagrid('reload');
			});
		},
		aid:function(){
			$winUser.dialog({    
			    title: '我的管理',    
			    width: 250,    
			    height: 350,    
			    closed: false,    
			    cache: false,       
			    modal: true,
			    buttons:[{
					text:'保存',
					iconCls:'icon-save',
					handler:function(){
						User.save();
					}
				},{
					text:'取消',
					iconCls:'icon-no',
					handler:function(){
						$winUser.window('close');
					}
				}],
			}); 
		},
	};
}) 
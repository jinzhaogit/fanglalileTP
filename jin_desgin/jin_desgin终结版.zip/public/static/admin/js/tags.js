$(function(){
	var $tagDg,$tagWin,$tagFm;
	$tagDg=$('#tagDg');$tagWin=$('#tagWin');$tagFm=$('#tagFm');
	$tagDg.datagrid({    
	    url:'/admin/Tags/getTagstab',
	    fitColumns:true,
	    striped:true,
	    fit:true,
	    pagination:true,
	    rownumbers:true,
	    singleSelect:true,  
	    toolbar: '#tagtb',
	    columns:[[  
	    	{field:'id',title:'ID',width:50},
	        {field:'title',title:'标题',width:100},    
	        {field:'tag',title:'主要内容',width:100,align:'right'},   
	    ]],    
	}); 
	Tags={
		url:'',
		add:function(){
			ue.setContent('');
			this.url='/admin/Tags/tagsAdd';
			Tags.aid();
		},
		del:function(){
			this.url='/admin/Tags/tagsDel';
			var row=$tagDg.datagrid('getSelected');
			if(row){
				$.post(this.url,{id:row.id},function(data){
					if(data>0){
						$.messager.show({
							title:'我的消息',
							msg:'删除成功',
							timeout:1500,
							showType:'slide'
						});
						$tagDg.datagrid('reload');    
					}else{
						alert('删除失败');
					}
				});
			}else{
				alert('请先选中一行哦~');
			}	
		},
		edit:function(){
			this.url='/admin/Tags/tagsEdit';
			var row=$tagDg.datagrid('getSelected');
			if(row){
				$tagFm.form('load',row);
				var content=this.htmlDecode(row.tag);
				this.init_ue();
				ue.ready(function(){
					ue.setContent(content);
				});
				Tags.aid();
			}else{
				alert('请先选中一行哦~');
			}	
		},
		aid:function(){
			$tagWin.dialog({    
			    title: '我的管理',    
			    width: 600,    
			    height: 500,    
			    closed: false,    
			    cache: false,       
			    modal: true, 
			    buttons:[{
			    	iconCls:'icon-save',
					text:'保存',
					handler:function(){
						Tags.save();
					}
				},{
					iconCls:'icon-no',
					text:'关闭',
					handler:function(){}
				}],

			});    
		},
		save:function(){
			var content=ue.getContent('content');
			var $objform=serializeObject($tagFm);
			$objform.tag=content;
			$.post(this.url,{ostr:JSON.stringify($objform)},function(data){
				if(data>0){
					$.messager.show({
						title:'我的消息',
						msg:'保存成功',
						timeout:1500,
						showType:'slide'
					});
					$tagWin.dialog('close');
					$tagDg.datagrid('reload');    
				}else{
					alert('保存失败');
				}
			});
		},
		htmlDecode:function (text){
	        //1.首先动态创建一个容器标签元素，如DIV
	        var temp = document.createElement("div");
	        //2.然后将要转换的字符串设置为这个元素的innerHTML(ie，火狐，google都支持)
	        temp.innerHTML = text;
	        //3.最后返回这个元素的innerText(ie支持)或者textContent(火狐，google支持)，即得到经过HTML解码的字符串了。
	        var output = temp.innerText || temp.textContent;
	        temp = null;
	        return output;
	    },
	    init_ue:function(){
	    	 ue = UE.getEditor('tag',{
		        UEDITOR_HOME_URL:admin+'/ueditor1.4.3.3/',
		        serverUrl :admin+'/ueditor1.4.3.3/php/controller.php'
		    });
	    },
	};

})
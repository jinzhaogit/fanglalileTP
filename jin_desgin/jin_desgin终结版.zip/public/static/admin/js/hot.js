$(function(){
	var $hotDg,$hotWin,$hotFm;
	$hotDg=$('#hotDg');$hotWin=$('#hotWin');$hotFm=$('#hotFm');
	$hotDg.datagrid({    
	    url:'/admin/Hot/getTabHot',
	    fitColumns:true,
	    striped:true,
	    fit:true,
	    pagination:true,
	    rownumbers:true,
	    singleSelect:true, 
	    pageSize:5,
	    pageList:[5,10,15,20],
	    toolbar: '#hotTb',
	    columns:[[  
	    	{field:'id',title:'ID',width:50},
	        {field:'name',title:'标题',width:100},    
	        {field:'hot',title:'热度',width:100,align:'right'},   
	    ]],    
	}); 
	Hot={
		url:'',
		add:function(){
			this.url='/admin/Hot/HotAdd';
			Hot.aid();
		},
		del:function(){
			this.url='/admin/Hot/HotDel';
			var row=$hotDg.datagrid('getSelected');
			if(row){
				$.post(this.url,{id:row.id},function(data){
					if(data>0){
						$.messager.show({
							title:'我的消息',
							msg:'删除成功',
							timeout:1500,
							showType:'slide'
						});
						$hotDg.datagrid('reload');    
					}else{
						alert('删除失败');
					}
				});
			}else{
				alert('请先选中一行哦~');
			}	
		},
		edit:function(){
			this.url='/admin/Hot/HotEdit';
			var row=$hotDg.datagrid('getSelected');
			if(row){
				$hotFm.form('load',row);
				Hot.aid();
			}else{
				alert('请先选中一行哦~');
			}	
		},
		query:function(){
			var name=$('#namehot').val();
			$hotDg.datagrid('load', {    
			    name: name, 
			});  
		},
		aid:function(){
			$hotWin.dialog({    
			    title: '我的管理',    
			    width: 200,    
			    height: 200,    
			    closed: false,    
			    cache: false,       
			    modal: true, 
			    buttons:[{
			    	iconCls:'icon-save',
					text:'保存',
					handler:function(){
						Hot.save();
					}
				},{
					iconCls:'icon-no',
					text:'关闭',
					handler:function(){}
				}],

			});    
		},
		save:function(){
			var $objform=serializeObject($hotFm);
			$.post(this.url,{ostr:JSON.stringify($objform)},function(data){
				if(data>0){
					$.messager.show({
						title:'我的消息',
						msg:'保存成功',
						timeout:1500,
						showType:'slide'
					});
					$hotWin.dialog('close');
					$hotDg.datagrid('reload');    
				}else{
					alert('保存失败');
				}
			});
		},
	};

})
$(function(){
	var $atDg,$artWin,$artFm,$artCc,$artCd,$artCe,$fformImg,$fmImg;
	$atDg=$('#atDg');$artWin=$('#artWin');$artFm=$('#artFm');$artCc=$('#cc');$artCd=$('#cd');
	$artCe=$('#ce');$fformImg=$('#fformImg');$fmImg=$('#fmImg');
	$atDg.datagrid({    
	    url:'/admin/Article/getAtrtab',  
	    fitColumns:true,
	    striped:true,
	    fit:true,
	    pagination:true,
	    rownumbers:true,
	    singleSelect:true,
	    pageSize:5,
		pageList:[5,10,15,20,25],
	    toolbar: '#tb',
	    columns:[[  
	    	{field:'id',title:'ID',width:50},
	        {field:'title',title:'标题',width:100},    
	        {field:'content',title:'简介',width:100}, 
	        {field:'img',title:'图片',width:100,
	        	formatter: function(value,row,index){
				if (value){
					return '<img width="100" height="50" src="\/'+value+'" />';
				} else {
					return value;
				}
				}
	        },
	        {field:'province',title:'省',width:100}, 
	        {field:'city',title:'市',width:100},
	        {field:'area',title:'区',width:100}, 
	        {field:'price',title:'价格',width:100,align:'right'}    
	    ]],    
	}); 
	$artCc.combobox({    
	    url:'/admin/Article/artProvince',    
	    valueField:'id',    
	    textField:'name', 
	    panelHeight:130,
	});
	$artCd.combobox({    
	    url:'/admin/Article/artCity',    
	    valueField:'id',    
	    textField:'name', 
	    panelHeight:130,
	});
	$artCe.combobox({    
	    url:'/admin/Article/artArea',    
	    valueField:'id',    
	    textField:'name', 
	    panelHeight:130,
	});
	$('#fb').filebox({    
	    buttonText: '选择文件', 
	    buttonAlign: 'left' 
	});
	article={
		url:'',
		add:function(){
			$artFm.form('clear');
			this.url='/admin/Article/artAdd';
			article.aid();
		},
		del:function(){
			this.url='/admin/Article/artDel';
			var row=$atDg.datagrid('getSelected');
			if(row){
				$.post(this.url,{id:row.id},function(data){
					if(data>0){
						$.messager.show({
							title:'我的消息',
							msg:'删除成功',
							timeout:1500,
							showType:'slide'
						});
						$atDg.datagrid('reload');    
					}else{
						alert('删除失败');
					}
				});
			}else{
				alert('请先选中一行哦~');
			}	
		},
		edit:function(){
			this.url='/admin/Article/artEdit';
			var row=$atDg.datagrid('getSelected');
			if(row){
				$artFm.form('load',row);
				article.eid();
			}else{
				alert('请先选中一行哦~');
			}	
		},
		editImg:function(){
			this.url='/admin/Article/editImg';
			var row=$atDg.datagrid('getSelected');
			$fformImg.find('img').attr('src','/'+row.img);
			$fmImg.val(row.id);
			$fformImg.dialog({    
			    title: '我的管理',    
			    width: 300,    
			    height: 350,    
			    closed: false,    
			    cache: false,       
			    modal: true, 
			    buttons:[{
			    	iconCls:'icon-save',
					text:'保存',
					handler:function(){
						article.saveImg();
					}
				},{
					iconCls:'icon-no',
					text:'关闭',
					handler:function(){
						$fformImg.window('close');
					}
				}],

			});    
		},
		query:function(){
			this.url='/admin/Article/artQuery';
			var title=$('#atitle').val();
			var city=$('#acity').val();
			$atDg.datagrid('load', {    
			    title: title,    
			    city: city   
			});  

		},
		eid:function(){
			$artWin.dialog({    
			    title: '我的管理',    
			    width: 300,    
			    height: 500,    
			    closed: false,    
			    cache: false,       
			    modal: true, 
			    buttons:[{
			    	iconCls:'icon-save',
					text:'保存',
					handler:function(){
						article.e_save();
					}
				},{
					iconCls:'icon-no',
					text:'关闭',
					handler:function(){
						$artWin.window('close');
					}
				}],

			});    
		},
		aid:function(){
			$artWin.dialog({    
			    title: '我的管理',    
			    width: 300,    
			    height: 500,    
			    closed: false,    
			    cache: false,       
			    modal: true, 
			    buttons:[{
			    	iconCls:'icon-save',
					text:'保存',
					handler:function(){
						article.save();
					}
				},{
					iconCls:'icon-no',
					text:'关闭',
					handler:function(){}
				}],

			});    
		},
		e_save:function(){
			var $objform=serializeObject($artFm);
			$.post(this.url,{ostr:JSON.stringify($objform)},function(data){
				if(data>0){
					$.messager.show({
						title:'我的消息',
						msg:'保存成功',
						timeout:1500,
						showType:'slide'
					});
					$artWin.dialog('close');
					$atDg.datagrid('reload');    
				}else{
					alert('保存失败');
				}
			});
		},
		save:function(){
			$artFm.ajaxSubmit({
	            type: 'post',
	            url: this.url,
	            success: function(data) {
	                if (data.status == '200') {
	                    $.messager.show({
	                        title: '成功',
	                        msg: '保存成功！！！',
	                        timeout: 1000,
	                        showType: 'slide'
	                    });
	                    $artWin.dialog('close');
	                    $atDg.datagrid('reload');
	                } else {
	                    $.messager.show({
	                        title: 'Error',
	                        msg: '保存失败！！！'
	                    });
	                }
	                $.messager.progress('close');
	            },
	            error: function(XmlHttpRequest, textStatus, errorThrown) {
	                console.log(XmlHttpRequest);
	                console.log(textStatus);
	                console.log(errorThrown);
	            }
	        });
		},
		saveImg:function(){
			$fformImg.ajaxSubmit({
	            type: 'post',
	            url: this.url,
	            success: function(data) {
	                if (data.status == '200') {
	                    $.messager.show({
	                        title: '成功',
	                        msg: '保存成功！！！',
	                        timeout: 1000,
	                        showType: 'slide'
	                    });
	                    $fformImg.dialog('close');
	                    $atDg.datagrid('reload');
	                } else {
	                    $.messager.show({
	                        title: 'Error',
	                        msg: '保存失败！！！'
	                    });
	                }
	                $.messager.progress('close');
	            },
	            error: function(XmlHttpRequest, textStatus, errorThrown) {
	                console.log(XmlHttpRequest);
	                console.log(textStatus);
	                console.log(errorThrown);
	            }
	        });
		},
	};

})
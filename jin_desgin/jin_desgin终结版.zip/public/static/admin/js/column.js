$(function(){
	var $dgCol,$winCol,$ffCol,$winColDb,$ffColDb;
	$dgCol=$('#dgCol');$winCol=$('#winCol');$ffCol=$('#ffCol');$winColDb=$('#winColDb');$ffColDb=$('#ffColDb');
	$dgCol.datagrid({    
	    url:'/admin/Column/getTabCol', 
	    fitColumns:true,
	    striped:true,
	    pagination:true,
	    rownumbers:true,
	    singleSelect:true,
	    fit:true,
	    pageSize:5,
	    pageList:[5,10,15,20],
	    toolbar: '#tbCol',
	    columns:[[    
	        {field:'id',title:'ID',width:50},    
	        {field:'logo',title:'Logo',width:70,
	        formatter: function(value,row,index){
				if (value){
					return '<img width="70" height="50" src="\/'+value+'" />';
				} else {
					return value;
				}
				}
	        },
	        {field:'alt',title:'Alt',width:50},
	        {field:'url',title:'链接',width:100,align:'right'}    
	    ]]    
	}); 
	$('#fb').filebox({    
	    buttonText: '选择文件', 
	    buttonAlign: 'right' 
	});
	column={
		url:'',
		add:function(){
			$ffCol.form('clear');
			this.url='/admin/Column/addCol';
			column.aid();
		},
		del:function(){
			this.url='/admin/Column/delCol';
			var row=$dgCol.datagrid('getSelected');
			if(row){
				$.post(this.url,{id:JSON.stringify(row.id)},function(data){
					if(data>0){
						$.messager.show({
	                        title: '成功',
	                        msg: '删除成功！！！',
	                        timeout: 1500,
	                        showType: 'slide'
	                   });
	                    $dgCol.datagrid('reload');
					}else{
						alert('抱歉，删除失败~');
					}
				});
			}else{
				alert('温馨提醒：亲，请先选择一条数据哦~谢谢');
			}
		},
		edit:function(){
			this.url='/admin/Column/editCol';
			var row=$dgCol.datagrid('getSelected');
			if(row){
				$ffColDb.find('img').attr('src','/'+row.logo);
				$('#ffColDbId').val(row.id);
				$ffColDb.form('load',row);
				column.aidDb();
			}else{
				alert('温馨提示：亲，清你先选择一条数据哦');
			}
		},
		query:function(){
			this.url='/admin/Article/queryCol';
			var alt=$('#alt').val();
			$dgCol.datagrid('load', {    
			    alt: alt, 
			});  
		},
		aid:function(){
			$winCol.dialog({    
			    title: '我的管理',    
			    width: 270,    
			    height: 260,    
			    closed: false,    
			    cache: false,       
			    modal: true,
			    buttons:[{
					text:'保存',
					handler:function(){
						column.save();
					}
				},{
					text:'关闭',
					handler:function(){
						$winCol.window('close');  
					}
				}]
			});    
		},
		aidDb:function(){
			$winColDb.dialog({    
			    title: '我的管理',    
			    width: 270,    
			    height: 360,    
			    closed: false,    
			    cache: false,       
			    modal: true,
			    buttons:[{
					text:'保存',
					handler:function(){
						column.saveDb();
					}
				},{
					text:'关闭',
					handler:function(){
						$winColDb.window('close');  
					}
				}]
			});    
		},
		save:function(){
			$ffCol.ajaxSubmit({
	            type: 'post',
	            url: this.url,
	            success: function(data) {
	                if (data.status == '200') {
	                    $.messager.show({
	                        title: '成功',
	                        msg: '保存成功！！！',
	                        timeout: 1000,
	                        showType: 'slide'
	                    });
	                    $winCol.dialog('close');
	                    $dgCol.datagrid('reload');
	                } else {
	                    $.messager.show({
	                        title: 'Error',
	                        msg: '保存失败！！！'
	                    });
	                }
	                $.messager.progress('close');
	            },
	            error: function(XmlHttpRequest, textStatus, errorThrown) {
	                console.log(XmlHttpRequest);
	                console.log(textStatus);
	                console.log(errorThrown);
	            }
	        });
		},
		saveDb:function(){
			$ffColDb.ajaxSubmit({
	            type: 'post',
	            url: this.url,
	            success: function(data) {
	                if (data.status == '200') {
	                    $.messager.show({
	                        title: '成功',
	                        msg: '保存成功！！！',
	                        timeout: 1000,
	                        showType: 'slide'
	                    });
	                    $winColDb.dialog('close');
	                    $dgCol.datagrid('reload');
	                } else {
	                    $.messager.show({
	                        title: 'Error',
	                        msg: '保存失败！！！'
	                    });
	                }
	                $.messager.progress('close');
	            },
	            error: function(XmlHttpRequest, textStatus, errorThrown) {
	                console.log(XmlHttpRequest);
	                console.log(textStatus);
	                console.log(errorThrown);
	            }
	        });
		},
	};

})

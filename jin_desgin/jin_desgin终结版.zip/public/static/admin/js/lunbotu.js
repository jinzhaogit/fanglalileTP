$(function(){
	var $dgLun,$winLun,$ffLun,$winLunDb,$ffLunDb;
	$dgLun=$('#dgLun');$winLun=$('#winLun');$ffLun=$('#ffLun');$winLunDb=$('#winLunDb');$ffLunDb=$('#ffLunDb');
	$dgLun.datagrid({    
	    url:'/admin/Lunbotu/getTabLun', 
	    fitLunbotus:true,
	    striped:true,
	    pagination:true,
	    rownumbers:true,
	    singleSelect:true,
	    fit:true,
	    pageSize:5,
	    pageList:[5,10,15,20],
	    toolbar: '#tbLun',
	    columns:[[    
	        {field:'id',title:'ID',width:50},    
	        {field:'tu',title:'轮播图',width:200,
	        formatter: function(value,row,index){
				if (value){
					return '<img width="70" height="50" src="\/'+value+'" />';
				} else {
					return value;
				}
				}
	        },
	        {field:'name',title:'名称',width:805,align:'right'}    
	    ]]    
	}); 
	$('#fb').filebox({    
	    buttonText: '选择文件', 
	    buttonAlign: 'right' 
	});
	Lunbotu={
		url:'',
		add:function(){
			$ffLun.form('clear');
			this.url='/admin/Lunbotu/addLun';
			Lunbotu.aid();
		},
		del:function(){
			this.url='/admin/Lunbotu/delLun';
			var row=$dgLun.datagrid('getSelected');
			if(row){
				$.post(this.url,{id:JSON.stringify(row.id)},function(data){
					if(data>0){
						$.messager.show({
	                        title: '成功',
	                        msg: '删除成功！！！',
	                        timeout: 1500,
	                        showType: 'slide'
	                   });
	                    $dgLun.datagrid('reload');
					}else{
						alert('抱歉，删除失败~');
					}
				});
			}else{
				alert('温馨提醒：亲，请先选择一条数据哦~谢谢');
			}
		},
		edit:function(){
			this.url='/admin/Lunbotu/editLun';
			var row=$dgLun.datagrid('getSelected');
			if(row){
				$ffLunDb.find('img').attr('src','/'+row.tu);
				$('#ffColDbId').val(row.id);
				$ffLunDb.form('load',row);
				Lunbotu.aidDb();
			}else{
				alert('温馨提示：亲，清你先选择一条数据哦');
			}
		},
		query:function(){
			this.url='/admin/Article/queryLun';
			var name=$('#nameLun').val();
			$dgLun.datagrid('load', {    
			    name: name, 
			});  
		},
		aid:function(){
			$winLun.dialog({    
			    title: '我的管理',    
			    width: 270,    
			    height: 260,    
			    closed: false,    
			    cache: false,       
			    modal: true,
			    buttons:[{
					text:'保存',
					handler:function(){
						Lunbotu.save();
					}
				},{
					text:'关闭',
					handler:function(){
						$winLun.window('close');  
					}
				}]
			});    
		},
		aidDb:function(){
			$winLunDb.dialog({    
			    title: '我的管理',    
			    width: 270,    
			    height: 360,    
			    closed: false,    
			    cache: false,       
			    modal: true,
			    buttons:[{
					text:'保存',
					handler:function(){
						Lunbotu.saveDb();
					}
				},{
					text:'关闭',
					handler:function(){
						$winLunDb.window('close');  
					}
				}]
			});    
		},
		save:function(){
			$ffLun.ajaxSubmit({
	            type: 'post',
	            url: this.url,
	            success: function(data) {
	                if (data.status == '200') {
	                    $.messager.show({
	                        title: '成功',
	                        msg: '保存成功！！！',
	                        timeout: 1000,
	                        showType: 'slide'
	                    });
	                    $winLun.dialog('close');
	                    $dgLun.datagrid('reload');
	                } else {
	                    $.messager.show({
	                        title: 'Error',
	                        msg: '保存失败！！！'
	                    });
	                }
	                $.messager.progress('close');
	            },
	            error: function(XmlHttpRequest, textStatus, errorThrown) {
	                console.log(XmlHttpRequest);
	                console.log(textStatus);
	                console.log(errorThrown);
	            }
	        });
		},
		saveDb:function(){
			$ffLunDb.ajaxSubmit({
	            type: 'post',
	            url: this.url,
	            success: function(data) {
	                if (data.status == '200') {
	                    $.messager.show({
	                        title: '成功',
	                        msg: '保存成功！！！',
	                        timeout: 1000,
	                        showType: 'slide'
	                    });
	                    $winLunDb.dialog('close');
	                    $dgLun.datagrid('reload');
	                } else {
	                    $.messager.show({
	                        title: 'Error',
	                        msg: '保存失败！！！'
	                    });
	                }
	                $.messager.progress('close');
	            },
	            error: function(XmlHttpRequest, textStatus, errorThrown) {
	                console.log(XmlHttpRequest);
	                console.log(textStatus);
	                console.log(errorThrown);
	            }
	        });
		},
	};

})
